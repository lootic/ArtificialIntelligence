java -cp ../lib/searchHidden.jar:. main.Main
